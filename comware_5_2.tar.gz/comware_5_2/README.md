Comware 5.2 Library for Ansible Comware 5.2 modules

This library is needed for the comware_5_2_x modules used to manage Comware 5.x-based switches (HP 1910 24GB, etc)
